# Prometheus + Grafana 監控平台交付包

這是一份可版控、可重建、可交接的 Docker Compose 監控平台。

## 第一次使用請依這個順序

1. 開啟 `操作說明.md`。
2. 對照 `需要替換的值清單.txt`，把實際設定檔中的 `CHANGE_ME` 全部換掉。
3. 執行 `chmod +x scripts/*.sh`。
4. 執行 `./scripts/validate.sh`。
5. 驗證全部通過後執行 `./scripts/deploy.sh`。

## Dashboard 版控

真正的 Dashboard JSON 位於：

```text
grafana/dashboards/
├── Network/cisco-switch-overview.json
├── Firewall/fortigate-overview.json
└── VMware/vmware-vsphere-overview.json
```

新增 Dashboard 的完整流程請看 `操作說明.md` 的「新增 Dashboard」章節與 `docs/Dashboard_JSON_欄位說明.md`。

> JSON 標準不支援 `#` / `//` 註解，因此 Dashboard JSON 使用合法的 `description` 欄位說明 Panel 用途；其餘 YAML / Shell / TOML 設定均附繁體中文註解。
