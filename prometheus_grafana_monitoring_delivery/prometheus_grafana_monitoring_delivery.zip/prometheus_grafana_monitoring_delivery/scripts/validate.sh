#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# 部署前驗證腳本
# =====================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

ERRORS=0

echo "[1/5] 檢查 .env ..."
if [[ ! -f .env ]]; then
  echo "ERROR: 找不到 .env"
  echo "交付包正常情況應該已附 .env；若遺失可執行：cp .env.example .env"
  ERRORS=1
else
  echo "OK: .env exists"
fi


echo
 echo "[2/5] 檢查 CHANGE_ME placeholder ..."
# .env.example 本來就應該保留 CHANGE_ME，所以排除。
# 操作說明與文件也會提到 CHANGE_ME，所以排除 docs / md。
# 先找 CHANGE_ME，再排除「純註解行」。
# 例如：# 請把 CHANGE_ME 改掉 只是說明文字，不應讓驗證失敗。
MATCHES="$(grep -RIn --exclude='.env.example' --exclude='*.md' --exclude='*.html' --exclude='*.zip' 'CHANGE_ME' \
  compose*.yml .env prometheus snmp blackbox fortigate vmware grafana 2>/dev/null \
  | grep -Ev '^[^:]+:[0-9]+:[[:space:]]*#' || true)"

if [[ -n "$MATCHES" ]]; then
  echo "ERROR: 還有以下 CHANGE_ME 尚未替換："
  echo "$MATCHES"
  ERRORS=1
else
  echo "OK: 沒有 CHANGE_ME placeholder"
fi


echo
 echo "[3/5] 驗證 Dashboard JSON ..."
if command -v python3 >/dev/null 2>&1; then
  python3 - <<'PYJSON'
import json
from pathlib import Path
files = list(Path('grafana/dashboards').rglob('*.json'))
for f in files:
    with f.open(encoding='utf-8') as fh:
        data = json.load(fh)
    if not data.get('uid'):
        raise SystemExit(f'ERROR: {f} 缺少 uid')
    print(f'OK: {f} uid={data["uid"]}')
PYJSON
else
  echo "WARN: 沒有 python3，跳過 JSON parser 驗證。"
fi


echo
 echo "[4/5] 驗證 Docker Compose ..."
if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: 找不到 docker 指令"
  ERRORS=1
else
  if docker compose version >/dev/null 2>&1; then
    if [[ -f .env ]]; then
      docker compose --profile vmware config --quiet
      echo "OK: docker compose config"
    else
      echo "SKIP: .env 不存在，無法執行 docker compose config"
    fi
  else
    echo "ERROR: 找不到 Docker Compose v2（docker compose）"
    ERRORS=1
  fi
fi


echo
 echo "[5/5] 驗證 Prometheus config ..."
if command -v docker >/dev/null 2>&1; then
  docker run --rm \
    -v "$ROOT_DIR/prometheus:/etc/prometheus:ro" \
    prom/prometheus:v3.13.2 \
    promtool check config /etc/prometheus/prometheus.yml
  echo "OK: promtool check config"
fi

if [[ "$ERRORS" -ne 0 ]]; then
  echo
  echo "=============================================="
  echo "驗證失敗：請先修正上面的 ERROR，再部署。"
  echo "=============================================="
  exit 1
fi

echo
 echo "=============================================="
echo "驗證完成：設定檔可進入部署階段。"
echo "=============================================="
