#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# 設定檔備份
#
# 備份的是 Repository Config，不直接備份 Docker Volume TSDB / SQLite DB。
# Secrets（.env / fortigate-key.yml）預設也不打包，避免備份檔外洩。
# =====================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="monitoring_config_backup_${STAMP}.tar.gz"

tar \
  --exclude='.env' \
  --exclude='fortigate/fortigate-key.yml' \
  --exclude='*.tar.gz' \
  -czf "$OUT" \
  compose.yml \
  compose.fortigate-insecure.override.yml \
  .env.example \
  .gitignore \
  操作說明.md \
  prometheus \
  snmp \
  blackbox \
  vmware \
  grafana \
  docs \
  scripts

echo "設定備份完成：$OUT"
