#!/usr/bin/env bash
set -euo pipefail

# =====================================================================
# 一鍵部署腳本
#
# 預設：Cisco + FortiGate + VMware 都啟動。
# 參數：
#   --no-vmware           不啟用 Telegraf vSphere profile
#   --fortigate-insecure  FortiGate Exporter 關閉 TLS 驗證（僅自簽憑證暫用）
# =====================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

WITH_VMWARE=1
FORTI_INSECURE=0

for arg in "$@"; do
  case "$arg" in
    --no-vmware)
      WITH_VMWARE=0
      ;;
    --fortigate-insecure)
      FORTI_INSECURE=1
      ;;
    *)
      echo "未知參數：$arg"
      echo "支援：--no-vmware --fortigate-insecure"
      exit 1
      ;;
  esac
done

# 部署前先強制驗證。
"$ROOT_DIR/scripts/validate.sh"

COMPOSE=(docker compose -f compose.yml)

if [[ "$FORTI_INSECURE" -eq 1 ]]; then
  COMPOSE+=( -f compose.fortigate-insecure.override.yml )
fi

if [[ "$WITH_VMWARE" -eq 1 ]]; then
  COMPOSE+=( --profile vmware )
fi

echo
 echo "拉取固定版本 Image ..."
"${COMPOSE[@]}" pull

echo
 echo "啟動監控平台 ..."
"${COMPOSE[@]}" up -d

echo
 echo "服務狀態："
"${COMPOSE[@]}" ps

echo
 echo "Grafana: http://<monitoring-server-ip>:3000"
echo "Prometheus: http://127.0.0.1:9090（預設只綁 localhost）"
