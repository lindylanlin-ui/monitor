# Dashboard JSON 欄位說明

> **重要：JSON 標準不允許 `#`、`//` 這類註解。**
>
> 因此 `grafana/dashboards/**/*.json` 不能直接加入程式註解，否則 Grafana Provisioning 會解析失敗。
> 本專案採以下方式保留說明：
>
> 1. Dashboard 頂層 `description`。
> 2. 每個 Panel 的 `description`。
> 3. 本文件說明常用 JSON 欄位。

## 常用欄位

| 欄位 | 意義 |
|---|---|
| `uid` | Dashboard 唯一 ID。**每一份 Dashboard 必須不同**。 |
| `title` | Grafana 顯示的 Dashboard 名稱。 |
| `description` | Dashboard 說明。 |
| `tags` | 搜尋與分類用。 |
| `refresh` | 自動刷新頻率，例如 `30s`。 |
| `time.from` / `time.to` | 預設時間範圍。 |
| `templating.list` | Dashboard 上方的變數 / 下拉選單。 |
| `panels` | Dashboard 所有 Panel。 |
| `panel.id` | 同一 Dashboard 內不可重複。 |
| `panel.gridPos` | Panel 的位置與大小。 |
| `panel.targets` | Query，例如 PromQL。 |
| `panel.fieldConfig` | Unit、Threshold、Value Mapping 等。 |
| `datasource.uid` | 本包固定使用 `prometheus`。 |

## 新 Dashboard 最安全的建立方式

不要從零手刻巨大 JSON。建議：

1. 在測試 Grafana 建立 Dashboard。
2. Panel / PromQL / Variable 都測試完成。
3. Dashboard → **Export / Save JSON to file**。
4. 確認 JSON 內 `uid` 不和既有 Dashboard 重複。
5. 存到：
   - `grafana/dashboards/Network/`
   - `grafana/dashboards/Firewall/`
   - `grafana/dashboards/VMware/`
   - 或自行新增分類資料夾。
6. 執行 `./scripts/validate.sh`。
7. `git diff` 確認變更。
8. Commit / Merge Request。
9. Production `git pull` 或 CI/CD Deploy。

Grafana `dashboards.yml` 設定 `foldersFromFilesStructure: true`，因此新增資料夾也會自動成為 Grafana Folder。
